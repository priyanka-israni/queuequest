const FRESHNESS_WINDOW_MINUTES = 90;

const STATUS_SCORE_MAP = {
  "very quiet": 95,
  "quiet": 85,
  "low noise": 82,
  "open classroom": 90,
  "seats available": 80,
  "available": 78,
  "moderate crowd": 55,
  "busy": 35,
  "crowded": 20,
  "full": 10,
};

const LOCATION_TYPE_WEIGHT = {
  study_spot: 8,
  classroom: 6,
  lab: 4,
  cafe: 3,
};

const TYPE_LABEL = {
  study_spot: "Study Spot",
  cafe: "Cafe",
  lab: "Lab",
  classroom: "Classroom",
};

const CAMPUS_LABEL = {
  penrhyn_road: "Penrhyn Road",
  kingston_hill: "Kingston Hill",
  knights_park: "Knights Park",
  roehampton_vale: "Roehampton Vale",
};

const fallbackByCampus = {
  penrhyn_road: [
    {
      place: "Town House Library - Level 3",
      status: "Very quiet",
      note: "Quiet reading area with several free desks",
      space_type: "study_spot",
      created_at: new Date().toISOString(),
    },
    {
      place: "Eadweard's Cafe",
      status: "Seats available",
      note: "Short queue and multiple open tables",
      space_type: "cafe",
      created_at: new Date(Date.now() - 16 * 60_000).toISOString(),
    },
    {
      place: "Sopwith Building - Computer Lab",
      status: "Moderate crowd",
      note: "About half the stations are currently in use",
      space_type: "lab",
      created_at: new Date(Date.now() - 41 * 60_000).toISOString(),
    },
    {
      place: "Main Building - Seminar Room 2.8",
      status: "Open classroom",
      note: "Open before the next scheduled teaching slot",
      space_type: "classroom",
      created_at: new Date(Date.now() - 71 * 60_000).toISOString(),
    },
  ],
  kingston_hill: [
    {
      place: "Kingston Business School - Study Lounge",
      status: "Quiet",
      note: "Several seats free near charging points",
      space_type: "study_spot",
      created_at: new Date().toISOString(),
    },
    {
      place: "Kingston Hill Campus Cafe",
      status: "Seats available",
      note: "Low queue at the counter",
      space_type: "cafe",
      created_at: new Date(Date.now() - 12 * 60_000).toISOString(),
    },
    {
      place: "Frank Lampl Building - IT Lab",
      status: "Moderate crowd",
      note: "Around half of PCs currently occupied",
      space_type: "lab",
      created_at: new Date(Date.now() - 33 * 60_000).toISOString(),
    },
    {
      place: "Business School - Seminar Room",
      status: "Open classroom",
      note: "Available until the next lecture",
      space_type: "classroom",
      created_at: new Date(Date.now() - 52 * 60_000).toISOString(),
    },
  ],
  knights_park: [
    {
      place: "Learning Resource Centre - Quiet Zone",
      status: "Very quiet",
      note: "Good desk availability",
      space_type: "study_spot",
      created_at: new Date().toISOString(),
    },
    {
      place: "Knights Park Restaurant and Bar",
      status: "Seats available",
      note: "Indoor tables available",
      space_type: "cafe",
      created_at: new Date(Date.now() - 15 * 60_000).toISOString(),
    },
    {
      place: "Design Studio Lab",
      status: "Moderate crowd",
      note: "Shared machines mostly in use",
      space_type: "lab",
      created_at: new Date(Date.now() - 37 * 60_000).toISOString(),
    },
    {
      place: "Workshop Teaching Room",
      status: "Open classroom",
      note: "Free before the next studio block",
      space_type: "classroom",
      created_at: new Date(Date.now() - 64 * 60_000).toISOString(),
    },
  ],
  roehampton_vale: [
    {
      place: "Engineering Learning Resource Area",
      status: "Quiet",
      note: "Plenty of desks at the back section",
      space_type: "study_spot",
      created_at: new Date().toISOString(),
    },
    {
      place: "Roehampton Vale Cafe",
      status: "Seats available",
      note: "Quick service and open seating",
      space_type: "cafe",
      created_at: new Date(Date.now() - 18 * 60_000).toISOString(),
    },
    {
      place: "Hawker Wing Engineering Lab",
      status: "Busy",
      note: "Practical session currently running",
      space_type: "lab",
      created_at: new Date(Date.now() - 28 * 60_000).toISOString(),
    },
    {
      place: "Main Building - Teaching Room",
      status: "Open classroom",
      note: "Open for group work right now",
      space_type: "classroom",
      created_at: new Date(Date.now() - 49 * 60_000).toISOString(),
    },
  ],
};

const feed = document.getElementById("feed");
const filterButtons = Array.from(document.querySelectorAll(".filter-btn"));
const connectionStatus = document.getElementById("connection-status");
const checkinForm = document.getElementById("checkin-form");
const formStatus = document.getElementById("form-status");
const bestPlaceLine = document.getElementById("best-place");
const trendLine = document.getElementById("trend-line");
const forecastLine = document.getElementById("forecast-line");

const config = window.QUEUEQUEST_CONFIG || {};
const apiBaseUrl = String(config.apiBaseUrl || "").trim();
const pollIntervalMs = Number(config.pollIntervalMs) > 0 ? Number(config.pollIntervalMs) : 15000;
const currentCampus = document.body.dataset.campus || "penrhyn_road";
const fallbackUpdates = fallbackByCampus[currentCampus] || fallbackByCampus.penrhyn_road;
const apiEndpoint = `${apiBaseUrl}/api/updates?campus=${encodeURIComponent(currentCampus)}`.replace(
  /([^:]\/)\/+/,
  "$1"
);
const streamEndpoint = `${apiBaseUrl}/api/stream`.replace(/([^:]\/)\/+/, "$1");
let stream = null;
let activeFilter = "all";

function setConnectionStatus(message, tone) {
  if (!connectionStatus) return;
  connectionStatus.textContent = message;
  connectionStatus.className = `connection-status ${tone || ""}`.trim();
}

function setFormStatus(message, tone) {
  if (!formStatus) return;
  formStatus.textContent = message;
  formStatus.className = `form-status ${tone || ""}`.trim();
}

function toRelativeTime(isoDate) {
  const date = new Date(isoDate);
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);

  if (Number.isNaN(seconds) || seconds < 0) return "Just now";
  if (seconds < 60) return "Just now";

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hr ago`;

  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

function normalizeStatus(status) {
  return String(status || "")
    .trim()
    .toLowerCase();
}

function scoreFromStatus(status) {
  const normalized = normalizeStatus(status);

  if (STATUS_SCORE_MAP[normalized] !== undefined) {
    return STATUS_SCORE_MAP[normalized];
  }

  if (normalized.includes("quiet") || normalized.includes("open")) return 85;
  if (normalized.includes("available") || normalized.includes("seats")) return 78;
  if (normalized.includes("moderate")) return 55;
  if (normalized.includes("busy")) return 35;
  if (normalized.includes("crowd") || normalized.includes("full")) return 20;

  return 50;
}

function getStatusBucket(status) {
  const normalized = normalizeStatus(status);

  if (normalized.includes("moderate")) return "moderate";
  if (
    normalized.includes("busy") ||
    normalized.includes("crowded") ||
    normalized.includes("full")
  ) {
    return "very-busy";
  }
  return "very-quiet";
}

function formatStatusBucket(bucket) {
  if (bucket === "moderate") return "Moderate";
  if (bucket === "very-busy") return "Very busy";
  return "Very quiet";
}

function freshnessScore(createdAt) {
  const minutesOld = (Date.now() - new Date(createdAt).getTime()) / 60000;
  if (!Number.isFinite(minutesOld)) return 0;

  const freshness = Math.max(0, 1 - minutesOld / FRESHNESS_WINDOW_MINUTES);
  return Math.round(freshness * 12);
}

function intelligenceScore(item) {
  const statusScore = scoreFromStatus(item.status);
  const typeWeight = LOCATION_TYPE_WEIGHT[item.space_type] || 0;
  const recencyBonus = freshnessScore(item.created_at);
  return statusScore + typeWeight + recencyBonus;
}

function filterFresh(items) {
  const cutoff = Date.now() - FRESHNESS_WINDOW_MINUTES * 60_000;
  return items.filter((item) => new Date(item.created_at).getTime() >= cutoff);
}

function formatTypeLabel(type) {
  return TYPE_LABEL[type] || "Campus Space";
}

function computeTrendArrow(items) {
  const now = Date.now();
  const last30 = items.filter(
    (item) => now - new Date(item.created_at).getTime() <= 30 * 60_000
  );
  const prev30 = items.filter((item) => {
    const ageMs = now - new Date(item.created_at).getTime();
    return ageMs > 30 * 60_000 && ageMs <= 60 * 60_000;
  });

  if (last30.length === 0 || prev30.length === 0) {
    return { arrow: "→", change: 0 };
  }

  const avg = (arr) =>
    arr.reduce((sum, item) => sum + intelligenceScore(item), 0) / Math.max(arr.length, 1);

  const delta = avg(last30) - avg(prev30);

  if (delta > 6) return { arrow: "↑", change: delta };
  if (delta < -6) return { arrow: "↓", change: delta };
  return { arrow: "→", change: delta };
}

function forecastMessage(trend, bestItem) {
  if (!bestItem) {
    return "No fresh updates yet. Ask students nearby to check in.";
  }

  if (trend.arrow === "↑") {
    return "Conditions are improving. More good options should open soon.";
  }

  if (trend.arrow === "↓") {
    return "Crowding is increasing. Good spots may fill up in the next hour.";
  }

  if (intelligenceScore(bestItem) >= 88) {
    return "Conditions are stable and favorable. This is a good time to head out.";
  }

  return "Conditions are stable. Expect similar availability over the next hour.";
}

function renderIntelligence(allItems) {
  const freshItems = filterFresh(allItems);

  if (freshItems.length === 0) {
    if (bestPlaceLine) {
      bestPlaceLine.innerHTML = `<strong>Best place:</strong> No fresh updates in the last ${FRESHNESS_WINDOW_MINUTES} minutes`;
    }
    if (trendLine) {
      trendLine.innerHTML = "<strong>Trend:</strong> → steady";
    }
    if (forecastLine) {
      forecastLine.innerHTML =
        "<strong>Forecast:</strong> Waiting for new reports. Submit an update to improve accuracy.";
    }
    return;
  }

  const ranked = [...freshItems].sort((a, b) => intelligenceScore(b) - intelligenceScore(a));
  const best = ranked[0];
  const trend = computeTrendArrow(freshItems);
  const forecast = forecastMessage(trend, best);

  if (bestPlaceLine) {
    bestPlaceLine.innerHTML = `<strong>Best place:</strong> ${best.place} (${formatTypeLabel(
      best.space_type
    )}) - ${best.status}`;
  }

  if (trendLine) {
    const trendText =
      trend.arrow === "↑" ? "improving" : trend.arrow === "↓" ? "getting busier" : "steady";
    trendLine.innerHTML = `<strong>Trend:</strong> ${trend.arrow} ${trendText}`;
  }

  if (forecastLine) {
    forecastLine.innerHTML = `<strong>Forecast:</strong> ${forecast}`;
  }
}

function renderFeed(items) {
  if (!feed) return;

  const freshItems = filterFresh(items);
  const visibleItems =
    activeFilter === "all"
      ? freshItems
      : freshItems.filter((item) => String(item.space_type) === activeFilter);

  feed.innerHTML = "";

  visibleItems.slice(0, 6).forEach((item) => {
    const li = document.createElement("li");
    const title = document.createElement("strong");
    title.textContent = item.place;

    const statusLine = document.createElement("span");
    const bucket = getStatusBucket(item.status);
    statusLine.className = `status-pill tone-${bucket}`;
    statusLine.textContent = `${formatStatusBucket(bucket)} (${formatTypeLabel(item.space_type)})`;

    const detail = document.createElement("small");
    const note = item.note ? `${item.note} • ` : "";
    detail.textContent = `${note}${toRelativeTime(item.created_at)}`;

    li.appendChild(title);
    li.appendChild(statusLine);
    li.appendChild(detail);
    feed.appendChild(li);
  });

  if (visibleItems.length === 0) {
    const li = document.createElement("li");
    li.innerHTML = `<strong>No matching updates</strong><small>Try another filter or submit a new check-in.</small>`;
    feed.appendChild(li);
  }

  renderIntelligence(items);
}

async function fetchUpdates() {
  try {
    const response = await fetch(apiEndpoint, { cache: "no-store" });

    if (!response.ok) {
      throw new Error(`API error ${response.status}`);
    }

    const payload = await response.json();
    const updates = Array.isArray(payload.updates) ? payload.updates : [];

    setConnectionStatus("Local backend connected. Live updates enabled.", "ok");
    renderFeed(updates);
  } catch (_error) {
    setConnectionStatus("Backend unavailable. Showing demo data.", "warn");
    renderFeed(fallbackUpdates);
  }
}

async function submitUpdate(event) {
  event.preventDefault();
  setFormStatus("", "");

  const formData = new FormData(checkinForm);
  const payload = {
    place: String(formData.get("place") || "").trim(),
    space_type: String(formData.get("space_type") || "").trim(),
    status: String(formData.get("status") || "").trim(),
    note: String(formData.get("note") || "").trim(),
    campus: currentCampus,
  };

  try {
    const response = await fetch(apiEndpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Could not submit update.");
    }

    checkinForm.reset();
    setFormStatus("Update posted.", "success");
    await fetchUpdates();
  } catch (error) {
    setFormStatus(error.message || "Could not submit update.", "error");
  }
}

function initBackend() {
  setConnectionStatus(`Connecting to ${CAMPUS_LABEL[currentCampus] || "campus"} backend...`, "ok");
  fetchUpdates();
  connectRealtimeStream();

  setInterval(() => {
    fetchUpdates();
  }, pollIntervalMs);
}

function setActiveFilter(nextFilter) {
  activeFilter = nextFilter;
  filterButtons.forEach((button) => {
    const isActive = button.dataset.filter === nextFilter;
    button.classList.toggle("active", isActive);
  });
  fetchUpdates();
}

function connectRealtimeStream() {
  if (!("EventSource" in window)) {
    setConnectionStatus("Live stream unsupported here. Using timed refresh.", "warn");
    return;
  }

  try {
    stream = new EventSource(streamEndpoint);

    stream.addEventListener("connected", () => {
      setConnectionStatus("Local backend connected. Live stream enabled.", "ok");
    });

    stream.addEventListener("update", () => {
      fetchUpdates();
    });

    stream.onerror = () => {
      setConnectionStatus("Live stream disconnected. Using timed refresh.", "warn");
    };
  } catch (_error) {
    setConnectionStatus("Live stream failed. Using timed refresh.", "warn");
  }
}

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
      }
    });
  },
  { threshold: 0.15 }
);

document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
if (checkinForm) checkinForm.addEventListener("submit", submitUpdate);
filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setActiveFilter(button.dataset.filter || "all");
  });
});

initBackend();

window.addEventListener("beforeunload", () => {
  if (stream) stream.close();
});
