window.QUEUEQUEST_CONFIG = {
  apiBaseUrl: "",
  pollIntervalMs: 15000
};
