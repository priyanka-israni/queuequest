const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 8080;
const DATA_FILE = path.join(__dirname, "data", "updates.json");
const sseClients = new Set();

app.use(express.json({ limit: "100kb" }));
app.use(express.static(__dirname));

const VALID_TYPES = new Set(["study_spot", "cafe", "lab", "classroom"]);
const VALID_CAMPUSES = new Set([
  "penrhyn_road",
  "kingston_hill",
  "knights_park",
  "roehampton_vale",
]);

async function readUpdates() {
  try {
    const raw = await fs.readFile(DATA_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

async function writeUpdates(items) {
  await fs.mkdir(path.dirname(DATA_FILE), { recursive: true });
  await fs.writeFile(DATA_FILE, JSON.stringify(items, null, 2));
}

function normalizePayload(body) {
  const place = String(body.place || "").trim();
  const spaceType = String(body.space_type || "").trim();
  const status = String(body.status || "").trim();
  const note = String(body.note || "").trim();
  const campus = String(body.campus || "").trim();

  if (!place || place.length > 120) {
    return { error: "Place is required and must be <= 120 characters." };
  }

  if (!VALID_TYPES.has(spaceType)) {
    return { error: "Type must be one of: study_spot, cafe, lab, classroom." };
  }

  if (!status || status.length > 80) {
    return { error: "Status is required and must be <= 80 characters." };
  }

  if (note.length > 180) {
    return { error: "Note must be <= 180 characters." };
  }

  if (!VALID_CAMPUSES.has(campus)) {
    return {
      error:
        "Campus must be one of: penrhyn_road, kingston_hill, knights_park, roehampton_vale.",
    };
  }

  return {
    value: {
      id: `u_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
      place,
      campus,
      space_type: spaceType,
      status,
      note,
      created_at: new Date().toISOString(),
    },
  };
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "queuequest-local-api" });
});

app.get("/api/stream", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");

  res.write("event: connected\n");
  res.write(`data: ${JSON.stringify({ ok: true })}\n\n`);

  sseClients.add(res);

  req.on("close", () => {
    sseClients.delete(res);
  });
});

function broadcastUpdate(update) {
  const payload = `event: update\ndata: ${JSON.stringify(update)}\n\n`;
  sseClients.forEach((client) => {
    client.write(payload);
  });
}

app.get("/api/updates", async (req, res) => {
  try {
    const updates = await readUpdates();
    const campus = String(req.query.campus || "").trim();
    const scoped = VALID_CAMPUSES.has(campus)
      ? updates.filter((item) => item.campus === campus)
      : updates;

    scoped.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    res.json({ updates: scoped });
  } catch (error) {
    res.status(500).json({ error: "Failed to load updates." });
  }
});

app.post("/api/updates", async (req, res) => {
  const normalized = normalizePayload(req.body || {});

  if (normalized.error) {
    return res.status(400).json({ error: normalized.error });
  }

  try {
    const updates = await readUpdates();
    updates.unshift(normalized.value);

    const pruned = updates
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 500);

    await writeUpdates(pruned);
    broadcastUpdate(normalized.value);
    return res.status(201).json({ update: normalized.value });
  } catch (error) {
    return res.status(500).json({ error: "Failed to save update." });
  }
});

app.listen(PORT, () => {
  console.log(`QueueQuest running on http://localhost:${PORT}`);
});
