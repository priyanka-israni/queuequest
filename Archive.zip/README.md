# QueueQuest (Local backend, no database)

This version runs with a local Node/Express backend and stores updates in `data/updates.json`.

## What you get
- `GET /api/updates` to read check-ins
- `POST /api/updates` to submit check-ins
- `GET /api/stream` for instant push updates (SSE)
- Persistent local storage in a JSON file (no Supabase, no SQL DB)
- Real-time delivery:
  - New check-ins are pushed immediately to all open clients
  - Timed polling remains as fallback
- Existing intelligence layer in the frontend:
  - Status -> score mapping
  - Location type weighting
  - Best place logic
  - 90-minute freshness filter
  - Trend arrow (↑ ↓ →)
  - Forecast message
- Multi-campus pages:
  - `index.html` -> Intro + How to Use + FAQ
  - `penrhyn-road.html` -> Penrhyn Road live page
  - `kingston-hill.html` -> Kingston Hill
  - `knights-park.html` -> Knights Park
  - `roehampton-vale.html` -> Roehampton Vale

## Setup (step by step)

1. Open terminal in this folder:

```bash
cd /Users/tanisha.adhyaicloud.com/Documents/Playground
```

2. Install dependencies:

```bash
npm install
```

3. Start the app:

```bash
npm start
```

4. Open in browser:

[http://localhost:8080](http://localhost:8080)

## Files
- Frontend page: `index.html`
- Additional campus pages: `penrhyn-road.html`, `kingston-hill.html`, `knights-park.html`, `roehampton-vale.html`
- Frontend logic: `script.js`
- Theme/styles: `styles.css`
- Local backend: `server.js`
- Backend config for frontend: `config.js`
- Local data store: `data/updates.json`

## Optional config
In `config.js`:

```js
window.QUEUEQUEST_CONFIG = {
  apiBaseUrl: "",
  pollIntervalMs: 15000
};
```

- Keep `apiBaseUrl` empty if frontend and backend run together on `localhost:8080`.
- Set `apiBaseUrl` only when your API is hosted on a different origin.
- Campus is selected from each page via `data-campus` on the `<body>` tag.
